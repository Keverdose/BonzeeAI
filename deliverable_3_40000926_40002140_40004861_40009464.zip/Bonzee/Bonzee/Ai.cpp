#include "Ai.h"



Ai::Ai()
{
}


Ai::~Ai()
{
}
