#pragma once

#include "CommonIncludes.h"


class HeuristicFunctions
{
public:
	
	/*static int Heuristic(char*);
	static int getRowIndex(int);
	static int getColumnIndex(int);
	void generateMap(int, int, int);*/
};
