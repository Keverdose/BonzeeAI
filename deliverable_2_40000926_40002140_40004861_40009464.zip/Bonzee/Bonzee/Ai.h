#pragma once
class Ai
{
public:
	Ai();
	~Ai();
};

